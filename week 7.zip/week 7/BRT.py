import tkinter as tk
from tkinter import messagebox

# === Red-Black Node ===
class RBNode:
    def __init__(self, name, phone, color='red'):
        self.name = name
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None

    def grandparent(self):
        return self.parent.parent if self.parent else None

    def uncle(self):
        gp = self.grandparent()
        if not gp:
            return None
        if self.parent == gp.left:
            return gp.right
        return gp.left


# === Red-Black Tree ===
class RBTree:
    def __init__(self):
        self.root = None

    # ROTATIONS
    def left_rotate(self, x):
        y = x.right
        x.right = y.left

        if y.left:
            y.left.parent = x

        y.parent = x.parent

        if not x.parent:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

    def right_rotate(self, x):
        y = x.left
        x.left = y.right

        if y.right:
            y.right.parent = x

        y.parent = x.parent

        if not x.parent:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y

        y.right = x
        x.parent = y

    # INSERT FIX
    def insert_fix(self, node):
        while node != self.root and node.parent.color == 'red':
            gp = node.grandparent()
            if not gp:
                break

            if node.parent == gp.left:
                uncle = gp.right

                if uncle and uncle.color == 'red':
                    node.parent.color = 'black'
                    uncle.color = 'black'
                    gp.color = 'red'
                    node = gp
                else:
                    if node == node.parent.right:
                        node = node.parent
                        self.left_rotate(node)

                    node.parent.color = 'black'
                    gp.color = 'red'
                    self.right_rotate(gp)
            else:
                uncle = gp.left

                if uncle and uncle.color == 'red':
                    node.parent.color = 'black'
                    uncle.color = 'black'
                    gp.color = 'red'
                    node = gp
                else:
                    if node == node.parent.left:
                        node = node.parent
                        self.right_rotate(node)

                    node.parent.color = 'black'
                    gp.color = 'red'
                    self.left_rotate(gp)

        self.root.color = 'black'

   
    def insert(self, root, name, phone):
        new_node = RBNode(name, phone)

        if self.root is None:
            self.root = new_node
            self.root.color = 'black'
            return self.root

        curr = self.root
        parent = None

        while curr:
            parent = curr
            if name < curr.name:
                curr = curr.left
            elif name > curr.name:
                curr = curr.right
            else:
                curr.phone = phone
                return self.root

        new_node.parent = parent

        if name < parent.name:
            parent.left = new_node
        else:
            parent.right = new_node

        self.insert_fix(new_node)

        return self.root

   
    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

 
    def inorder(self, root, res=None):
        if res is None:
            res = []
        if root:
            self.inorder(root.left, res)
            res.append((root.name, root.phone))
            self.inorder(root.right, res)
        return res


# === GUI ===
class RBApp:
    def __init__(self, master):
        self.tree = RBTree()

        master.title("Red-Black Contact Directory")

        frame = tk.Frame(master)
        frame.pack(pady=10)

        tk.Label(frame, text="Name:").grid(row=0, column=0)
        self.name_entry = tk.Entry(frame)
        self.name_entry.grid(row=0, column=1)

        tk.Label(frame, text="Phone:").grid(row=1, column=0)
        self.phone_entry = tk.Entry(frame)
        self.phone_entry.grid(row=1, column=1)

        btn_frame = tk.Frame(master)
        btn_frame.pack()

        tk.Button(btn_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0)
        tk.Button(btn_frame, text="Search", command=self.search_contact).grid(row=0, column=1)
        tk.Button(btn_frame, text="Show All", command=self.show_all).grid(row=0, column=2)

        self.output_text = tk.Text(master, height=10, width=60)
        self.output_text.pack()

        self.canvas = tk.Canvas(master, width=800, height=400, bg="white")
        self.canvas.pack()

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()

        if not name or not phone:
            messagebox.showwarning("Error", "Enter name and phone")
            return

        self.tree.root = self.tree.insert(self.tree.root, name, phone)

        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        node = self.tree.search(self.tree.root, name)

        self.output_text.delete(1.0, tk.END)
        if node:
            self.output_text.insert(tk.END, f"{node.name}: {node.phone}")
        else:
            self.output_text.insert(tk.END, "Not found")

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        for n, p in self.tree.inorder(self.tree.root):
            self.output_text.insert(tk.END, f"{n}: {p}\n")

    def draw_tree(self):
        self.canvas.delete("all")
        self._draw(self.tree.root, 400, 20, 200)

    def _draw(self, node, x, y, offset):
        if not node:
            return

        color = "red" if node.color == "red" else "black"

        if node.left:
            self.canvas.create_line(x, y, x - offset, y + 70)
            self._draw(node.left, x - offset, y + 70, offset // 2)

        if node.right:
            self.canvas.create_line(x, y, x + offset, y + 70)
            self._draw(node.right, x + offset, y + 70, offset // 2)

        self.canvas.create_oval(x-20, y-20, x+20, y+20, fill=color)
        self.canvas.create_text(x, y, text=node.name, fill="white")



root = tk.Tk()
app = RBApp(root)
root.mainloop()