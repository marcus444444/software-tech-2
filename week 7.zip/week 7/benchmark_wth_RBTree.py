import time
import random
import string
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None

class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

    def find_min(self, root):
        while root.left:
            root = root.left
        return root

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1

class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        return self.height(node.left) - self.height(node.right) if node else 0

    def right_rotate(self, z):
        y = z.left
        T3 = y.right
        y.right = z
        z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left
        y.left = z
        z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node
        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)
        return node

    def min_value_node(self, node):
        while node.left:
            node = node.left
        return node

    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)
        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)



class RBNode:
    def __init__(self, name, phone, color='red'):
        self.name = name
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None


    def grandparent(self):
        return self.parent.parent if self.parent else None




class RBTree:


    def __init__(self):
        self.root = None



    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left:
            y.left.parent = x
        y.parent = x.parent
        if not x.parent:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y



    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right:
            y.right.parent = x
        y.parent = x.parent
        if not x.parent:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y



    def insert_fix(self, node):
        while node != self.root and node.parent.color == 'red':
            gp = node.grandparent()
            if node.parent == gp.left:
                uncle = gp.right
                if uncle and uncle.color == 'red':
                    node.parent.color = 'black'
                    uncle.color = 'black'
                    gp.color = 'red'
                    node = gp
                else:
                    if node == node.parent.right:
                        node = node.parent
                        self.left_rotate(node)
                    node.parent.color = 'black'
                    gp.color = 'red'
                    self.right_rotate(gp)
            else:
                uncle = gp.left
                if uncle and uncle.color == 'red':
                    node.parent.color = 'black'
                    uncle.color = 'black'
                    gp.color = 'red'
                    node = gp
                else:
                    if node == node.parent.left:
                        node = node.parent
                        self.right_rotate(node)
                    node.parent.color = 'black'
                    gp.color = 'red'
                    self.left_rotate(gp)
        self.root.color = 'black'

    def insert(self, root, name, phone):
        new_node = RBNode(name, phone)
        if self.root is None:
            self.root = new_node
            self.root.color = 'black'
            return self.root
        curr = self.root
        parent = None
        while curr:
            parent = curr
            if name < curr.name:
                curr = curr.left
            elif name > curr.name:
                curr = curr.right
            else:
                curr.phone = phone
                return self.root
        new_node.parent = parent
        if name < parent.name:
            parent.left = new_node
        else:
            parent.right = new_node
        self.insert_fix(new_node)
        return self.root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

def benchmark(n=10000, search_fraction=0.5, delete_count=2000, verbose=True):
    names = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

    bst = BST()
    start = time.perf_counter()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert_time = time.perf_counter() - start

    search_names = random.sample(names, int(n*search_fraction)) + ['notfoundname'] * int(n*(1 - search_fraction))
    start = time.perf_counter()
    found_bst = sum(1 for name in search_names if bst.search(bst.root, name))
    bst_search_time = time.perf_counter() - start



    delete_names = random.sample(names, delete_count)
    start = time.perf_counter()
    for name in delete_names:
        bst.root = bst.delete(bst.root, name)
    bst_delete_time = time.perf_counter() - start

    avl = AVLTree()
    start = time.perf_counter()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert_time = time.perf_counter() - start



    start = time.perf_counter()
    found_avl = sum(1 for name in search_names if avl.search(avl.root, name))
    avl_search_time = time.perf_counter() - start

    start = time.perf_counter()
    for name in delete_names:
        avl.root = avl.delete(avl.root, name)
    avl_delete_time = time.perf_counter() - start



    rb = RBTree()
    start = time.perf_counter()
    for i in range(n):
        rb.root = rb.insert(rb.root, names[i], phones[i])
    rb_insert_time = time.perf_counter() - start


    start = time.perf_counter()
    found_rb = sum(1 for name in search_names if rb.search(rb.root, name))
    rb_search_time = time.perf_counter() - start



    results = {
        'Insertions': (bst_insert_time, avl_insert_time, rb_insert_time),
        'Searches': (bst_search_time, avl_search_time, rb_search_time),
        'Deletions': (bst_delete_time, avl_delete_time, 0),
        'Found In Search': (found_bst, found_avl, found_rb)
    }


    if verbose:
        print(f"Benchmarking with {n} entries:\n")
        print("Operation        BST time (sec)          AVL time (sec)             RB time (sec)")
        print("---------------------------------------------")
        print(f"Insertions:    {bst_insert_time:.10f}   {avl_insert_time:.10f}   {rb_insert_time:.10f}")
        print(f"Searches:      {bst_search_time:.10f}   {avl_search_time:.10f}   {rb_search_time:.10f}")
        print(f"Deletions:     {bst_delete_time:.10f}   {avl_delete_time:.10f}   ")
        print("---------------------------------------------")

    return results



def run_benchmark_for_sizes(sizes, num_search=100, num_delete=2000):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}
    rb_times = {'insert': [], 'search': [], 'delete': []}



    for n in sizes:
        names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
        search_names = random.sample(names, min(num_search, n))
        delete_names = random.sample(names, min(num_delete, n))

        bst = BST()
        start = time.perf_counter()
        for i in range(n):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_times['insert'].append(time.perf_counter() - start)

        start = time.perf_counter()
        for name in search_names:
            bst.search(bst.root, name)
        bst_times['search'].append(time.perf_counter() - start)

        start = time.perf_counter()
        for name in delete_names:
            bst.root = bst.delete(bst.root, name)
        bst_times['delete'].append(time.perf_counter() - start)

        avl = AVLTree()
        start = time.perf_counter()
        for i in range(n):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_times['insert'].append(time.perf_counter() - start)

        start = time.perf_counter()
        for name in search_names:
            avl.search(avl.root, name)
        avl_times['search'].append(time.perf_counter() - start)

        start = time.perf_counter()
        for name in delete_names:
            avl.root = avl.delete(avl.root, name)
        avl_times['delete'].append(time.perf_counter() - start)

        rb = RBTree()
        start = time.perf_counter()
        for i in range(n):
            rb.root = rb.insert(rb.root, names[i], phones[i])
        rb_times['insert'].append(time.perf_counter() - start)

        start = time.perf_counter()
        for name in search_names:
            rb.search(rb.root, name)
        rb_times['search'].append(time.perf_counter() - start)

        rb_times['delete'].append(0)



    plt.figure(figsize=(12, 8))

    plt.subplot(3, 1, 1)
    plt.plot(sizes, bst_times['insert'], label='BST Insert')
    plt.plot(sizes, avl_times['insert'], label='AVL Insert')
    plt.plot(sizes, rb_times['insert'], label='RB Insert')
    plt.ylabel('Time (seconds)')
    plt.title('Insertion Time vs Input Size')
    plt.legend()

    plt.subplot(3, 1, 2)
    plt.plot(sizes, bst_times['search'], label='BST Search')
    plt.plot(sizes, avl_times['search'], label='AVL Search')
    plt.plot(sizes, rb_times['search'], label='RB Search')
    plt.ylabel('Time (seconds)')
    plt.title('Search Time vs Input Size')
    plt.legend()

    plt.subplot(3, 1, 3)
    plt.plot(sizes, bst_times['delete'], label='BST Delete')
    plt.plot(sizes, avl_times['delete'], label='AVL Delete')
    plt.plot(sizes, rb_times['delete'], label='RB Delete')
    plt.xlabel('Number of Nodes')
    plt.ylabel('Time (seconds)')
    plt.title('Deletion Time vs Input Size')
    plt.legend()

    plt.tight_layout()
    plt.show()



class BenchmarkApp:
    def __init__(self, master):
        self.master = master
        master.title("BST vs AVL vs RB Benchmark")

        self.label = tk.Label(master, text="Run benchmark with 1000 entries?")
        self.label.pack(pady=5)

        self.run_btn = tk.Button(master, text="Run Benchmark", command=self.run_benchmark)
        self.run_btn.pack(pady=5)

        self.result_text = tk.Text(master, height=15, width=60)
        self.result_text.pack(pady=10)

        self.tree = ttk.Treeview(master, columns=("BST", "AVL", "RBT"), show='headings')
        self.tree.heading("BST", text="BST Time (s)")
        self.tree.heading("AVL", text="AVL Time (s)")
        self.tree.heading("RBT", text="RB Time (s)")
        self.tree.pack(pady=10)


    def run_benchmark(self):
        self.result_text.delete(1.0, tk.END)
        results = benchmark(verbose=False)

        summary = (
            f"Insertion Time: BST: {results['Insertions'][0]:.10f}s, AVL: {results['Insertions'][1]:.10f}s, RB: {results['Insertions'][2]:.10f}s\n"

            f"Search Time:    BST: {results['Searches'][0]:.10f}s, AVL: {results['Searches'][1]:.10f}s, RB: {results['Searches'][2]:.10f}s\n"

            f"Deletion Time:  BST: {results['Deletions'][0]:.10f}s, AVL: {results['Deletions'][1]:.10f}s, RB: {results['Deletions'][2]:.10f}s\n"
        )

        self.result_text.insert(tk.END, summary)



        for row in self.tree.get_children():
            self.tree.delete(row)

        for op in ['Insertions', 'Searches', 'Deletions']:
            bst_time, avl_time, rb_time = results[op]
            self.tree.insert('', tk.END, values=(f"{bst_time:.10f}", f"{avl_time:.10f}", f"{rb_time:.10f}"))

if __name__ == "__main__":
    root = tk.Tk()
    app = BenchmarkApp(root)
    sizes_to_test = [100, 200, 400, 800, 1600, 4000, 7000]
    run_benchmark_for_sizes(sizes_to_test)
    root.mainloop()