def main(): 
    global total_moves

    n = eval(input("Enter number of disks: ")) 
    # Find the solution recursively 
    print("The moves are:") 
    moveDisks(n, 'A', 'B', 'C') 
    # The function for finding the solution to move n disks 
    #   from fromTower to toTower with auxTower  
    print("\nNumber of moves is ", total_moves)


def moveDisks(n, fromTower, toTower, auxTower): 
    global total_moves

    if n == 1: # Stopping condition 
        print("Move disk", n, "from", fromTower, "to", toTower) 
        total_moves += 1
      

    else:  
        moveDisks(n - 1, fromTower, auxTower, toTower) 
        print("Move disk", n, "from", fromTower, "to", toTower) 
        moveDisks(n - 1, auxTower, toTower, fromTower) 
        total_moves += 1


total_moves = 0


main() # Call the main function