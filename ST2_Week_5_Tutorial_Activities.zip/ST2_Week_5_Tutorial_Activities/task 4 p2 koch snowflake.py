from tkinter import *
import math

class Kochsnowflake:
    def __init__(self):
        window = Tk()
        window.title("koch snowflake")

        self.width = 400
        self.height = 400

        self.canvas = Canvas(window,
            width=self.width, height=self.height)
        self.canvas.pack()

        frame1 = Frame(window)
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)

        self.order = StringVar()
        Entry(frame1, textvariable=self.order,
            justify=RIGHT).pack(side=LEFT)

        Button(frame1, text="Display Koch snoflake",
            command=self.display).pack(side=LEFT)

        window.mainloop()




    def display(self):
        self.canvas.delete("line")

        #dimentions 
        p1 = [self.width / 2, 30]
        p2 = [10, self.height - 30]
        p3 = [self.width - 30, self.height - 30]

        order = int(self.order.get())

        # Draw 3 sides
        self.drawKoch(order, p1, p2)
        self.drawKoch(order, p2, p3)
        self.drawKoch(order, p3, p1)

    def drawKoch(self, order, p1, p2):
        if order == 0:

            self.drawLine(p1, p2)

        else:
            #pA is 1/3 between p1 and p2 and pB is 2/3
            pA = self.midpoint(p1, p2, 1)
            pB = self.midpoint(p1, p2, 2)

            # make the spikes
            pPeak = self.getPeak(pA, pB)

            self.drawKoch(order - 1, p1, pA)
            self.drawKoch(order - 1, pA, pPeak)
            self.drawKoch(order - 1, pPeak, pB)
            self.drawKoch(order - 1, pB, p2)



    def drawLine(self, p1, p2):
        self.canvas.create_line(
            p1[0], p1[1], p2[0], p2[1], tags="line")


    def midpoint(self, p1, p2, part):
        #split line into 3 parts 
        return [
            p1[0] + (p2[0] - p1[0]) * part / 3,
            p1[1] + (p2[1] - p1[1]) * part / 3 ]

 
    def getPeak(self, p1, p2):
        angle = math.radians(60)

        dx = p2[0] - p1[0]
        dy = p2[1] - p1[1]

        x = p1[0] + dx * math.cos(angle) - dy * math.sin(angle)
        y = p1[1] + dx * math.sin(angle) + dy * math.cos(angle)

        return [x, y]


Kochsnowflake()