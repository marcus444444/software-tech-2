from graph import Graph
import tkinter as tk
import math

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.graph = graph
        self.canvas = tk.Canvas(self, width=500, height=500, bg='white')
        self.canvas.pack()

        # Single input box
        self.input_entry = tk.Entry(self, width=20)
        self.input_entry.pack(pady=10)

        # Buttons
        self.control_frame = tk.Frame(self)
        self.control_frame.pack(pady=10)
        tk.Button(self.control_frame, text="Add Vertex", command=self.add_vertex).grid(row=0, column=0)
        tk.Button(self.control_frame, text="Remove Vertex", command=self.remove_vertex).grid(row=0, column=1)
        tk.Button(self.control_frame, text="Add Edge", command=self.add_edge).grid(row=0, column=2)
        tk.Button(self.control_frame, text="Remove Edge", command=self.remove_edge).grid(row=0, column=3)

        tk.Button(self.control_frame, text="Animate BFS", command=lambda: self.animate_bfs("A")).grid(row=4, column=1, pady=5)
        tk.Button(self.control_frame, text="Animate DFS", command=lambda: self.animate_dfs("A")).grid(row=4, column=2, pady=5)

        self.vertex_positions = {}
        self.draw_graph()


    def draw_graph(self, highlight=None):  
        self.canvas.delete("all")
        radius = 20
        spacing = 150
        n = len(self.graph.graph)
        angle_gap = 360 / n if n else 0
        center_x, center_y = 250, 250

        for i, v in enumerate(self.graph.graph):
            angle = i * angle_gap
            x = center_x + spacing * math.cos(math.radians(angle))
            y = center_y + spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)

            color = "lightblue"
            if v == highlight:
                color = "yellow"

            self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=color)
            self.canvas.create_text(x, y, text=v)

        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]
                self.canvas.create_line(
                    x1, y1, x2, y2,
                    arrow=tk.LAST if self.graph.directed else None
                )

                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), '')
                    mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(w), fill="red")



    # Button functions
    def add_vertex(self):
        vertex = self.input_entry.get().strip()
        if vertex:
            self.graph.add_vertex(vertex)
            self.draw_graph()

    def remove_vertex(self):
        vertex = self.input_entry.get().strip()
        if vertex:
            self.graph.remove_vertex(vertex)
            self.draw_graph()

    def add_edge(self):
        text = self.input_entry.get().strip()
        # Expect format: A,B,weight (weight optional)
        if ',' in text:
            parts = text.split(',')
            u, v = parts[0].strip(), parts[1].strip()
            weight = int(parts[2].strip()) if len(parts) > 2 and parts[2].strip().isdigit() else None
            self.graph.add_edge(u, v, weight)
            self.draw_graph()
            



    def remove_edge(self):
        text = self.input_entry.get().strip()
        # Expect format: A,B
        if ',' in text:
            u, v = text.split(',')
            self.graph.remove_edge(u.strip(), v.strip())
            self.draw_graph()






    def animate_bfs(self, start):
        visited = []
        queue = [start]

        def step():
            if queue:
                node = queue.pop(0)

                if node not in visited:
                    visited.append(node)

                    for neighbor in self.graph.graph.get(node, []):
                        queue.append(neighbor)

                    self.draw_graph(highlight=node)
                    self.after(600, step)

        step()


    def animate_dfs(self, start):
        visited = []
        stack = [start]

        def step():
            if stack:
                node = stack.pop()

                if node not in visited:
                    visited.append(node)


                    for neighbor in self.graph.graph.get(node, []):
                        stack.append(neighbor)

                    self.draw_graph(highlight=node)
                    self.after(600, step)

        step()




if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)
    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex ('C')
    g.add_edge('A', 'B', 10)
    g.add_edge('B', 'C', 40)
    g.add_edge('C', 'A', 20)

    app = GraphVisualizer(g)
    app.mainloop()