

class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph: # Check that vertices are present
            # store vertex and weight as a tuple
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed: # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")


    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if self.weighted:
                self.weights.pop((vertex1, vertex2), None)
        if not self.directed and vertex2 in self.graph and vertex1 in self.graph[vertex2]:
            self.graph[vertex2].remove(vertex1)
            if self.weighted:
                self.weights.pop((vertex2, vertex1), None)


    def remove_vertex(self, vertex):
        if vertex in self.graph:
  
            for v in self.graph:

                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)
                    if self.weighted:
                        self.weights.pop((v, vertex), None)
           

            if self.weighted:

                for v2 in self.graph[vertex]:
                    self.weights.pop((vertex, v2), None)
            self.graph.pop(vertex)



    def print_graph(self):
        for vertex in self.graph:
            edges = self.graph[vertex]
            if self.weighted:

                edge = ", ".join(
                    f"{v}({self.weights[(vertex, v)]})" 
                    
                    if (vertex, v) in self.weights 
                    
                    else 
                    f"{v}"

                    for v in edges
                )
            else:
                edge = ", ".join(edges)
            print(f"{vertex} -> {edge}")



    def bfs(self, first_vertex):
        visited_bfs = []
        queue = [first_vertex]
        order = []

        while len(queue) > 0:

            vertex = queue.pop(0)

            if vertex not in visited_bfs:
                visited_bfs.append(vertex)
                order.append(vertex)

            for neighbor in self.graph[vertex]:
                if neighbor not in visited_bfs:
                    queue.append(neighbor)

        print ("BFS")
        print("->".join(order))
        return order
        

    def dfs(self, first_vertex):
        visited_dfs = []
        stack = [first_vertex]  
        order = []

        while len(stack) > 0:

            vertex = stack.pop()   

            if vertex not in visited_dfs:
                visited_dfs.append(vertex)
                order.append(vertex)

                for neighbor in reversed(self.graph.get(vertex, [])):  #reversed for lifo
                    if neighbor not in visited_dfs:
                        stack.append(neighbor)

        print ("\nDFS")
        print("->".join(order))
        return order
    

    def has_undirected_cycle(self):
        visited = set()

        def dfs(vertex, parent):

            visited.add(vertex)

            for neighbor in self.graph.get(vertex, []):
                if neighbor not in visited:
                    if dfs(neighbor, vertex):
                        return True
                    
                elif neighbor != parent:
                    return True
                
            return False

        # run form all vertices incase gragph is disconnencted
        for vertex in self.graph:
            if vertex not in visited:
                if dfs(vertex, None):
                    return True
                
        return False # no cycles found 

 